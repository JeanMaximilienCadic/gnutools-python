import time
from datetime import timedelta
from concurrent.futures import ProcessPoolExecutor, as_completed
from rich.progress import Progress


class ProcessPoolExecutorBar:
    def __init__(self):
        self._results = []
        self._exceptions = []
        self.t0 = None
        self.N = None

    def submit(self, tasks, *args, **kwargs):
        self.N = len(tasks)
        with Progress() as progress:
            task1 = progress.add_task("[red]Sending context...", total=self.N)
            with ProcessPoolExecutor(*args, **kwargs) as e:
                fs = [e.submit(*t) for t in tasks]
                for k, f in enumerate(as_completed(fs)):
                    self.t0 = self.t0 if self.t0 is not None else time.time()
                    _exception = f.exception()
                    if _exception is None:
                        self._results.append(f.result())
                    else:
                        self._results.append(None)
                    self._exceptions.append(_exception)
                    progress.tasks[0].description = f"{self.description_left(k)} | {self.description_right(k)}"
                    progress.update(task1, advance=1)

    def description_right(self, k):
        try:
            return f"[red]Processing {k}/{self.N}"
        except:
            return f"[red]Processing ?/?"

    def description_left(self, k):
        time_elapsed = int(time.time()-self.t0)
        try:
            return f"[blue]{timedelta(seconds=time_elapsed)} {format(k/time_elapsed, '.2f')}it/s"
        except:
            return f"[blue] ? it/s"
